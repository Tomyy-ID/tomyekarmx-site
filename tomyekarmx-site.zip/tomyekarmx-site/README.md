# Website Tomy Eka RMX «BSB»

Website multi-halaman dengan login admin. File project (FLM + vocal + sample) terbuka otomatis setelah video YouTube mencapai target view (default 1.000), dicek lewat YouTube Data API.

## Halaman

| URL | Fungsi |
|---|---|
| `/` | Beranda, statistik, project terbaru, cara dapat FLM |
| `/project` | Daftar semua project (cari + filter Terbuka/Terkunci) |
| `/project/<slug>` | Detail: video, progress view, tombol download |
| `/about`, `/contact` | Tentang dan kontak |
| `/admin/login`, `/admin` | Login admin dan dashboard |

## Menjalankan

Butuh Node.js 20 atau lebih baru.

```bash
npm install
cp .env.example .env      # lalu isi YOUTUBE_API_KEY, ADMIN_USER, ADMIN_PASS
npm start
```

Kalau `ADMIN_PASS` kosong, password acak dicetak di console saat pertama jalan. Segera ganti lewat tombol "Ganti password" di dashboard.

## Mendapatkan YouTube API key

1. Buka Google Cloud Console, buat project baru.
2. Aktifkan **YouTube Data API v3**.
3. Buat kredensial **API key**, lalu batasi hanya untuk YouTube Data API v3.
4. Tempel ke `YOUTUBE_API_KEY` di `.env`, lalu restart server.

Kuota gratis 10.000 unit/hari. Server hanya membutuhkan 1 unit per pengecekan (semua video digabung dalam satu permintaan) dan menyimpan hasil 10 menit, jadi sangat hemat.

## Cara kerja gembok 1K view

- Admin menambah project: judul, link video, dan upload file `.flm`, vocal, sample.
- Server mengecek `viewCount` video lewat YouTube API. Begitu view mencapai target, project ditandai **terbuka** dan tidak terkunci lagi, meskipun view turun kemudian.
- Penjagaan dilakukan di **server**. Alamat download diperiksa ulang setiap permintaan, dan file disimpan di luar folder publik dengan nama acak, jadi tidak bisa ditembus lewat URL.
- Nama file saat diunduh otomatis mengikuti judul video, misalnya `Judul Video - FLM Project.flm`, `Judul Video - Vocal.wav`, `Judul Video - Sample.zip`.
- Target view bisa diatur per project. Opsi "Buka file manual" tersedia untuk uji coba atau kasus khusus.

## Hosting

Website ini butuh server Node.js (ada login, upload, dan API), jadi **tidak bisa** di hosting statis seperti GitHub Pages. Pilih VPS atau platform yang mendukung Node.js dengan penyimpanan persisten, lalu arahkan domain `tomyekarmx.dpdns.org` ke sana. Penting:

- Simpan folder `data/` (atau `DATA_DIR`) di disk persisten, karena berisi database dan semua file upload. Lakukan backup rutin.
- Di produksi pakai HTTPS, lalu set `COOKIE_SECURE=1`. Jika di belakang proxy/Cloudflare, set `TRUST_PROXY=1`.
- Sesuaikan batas upload di reverse proxy (misalnya Nginx `client_max_body_size`) dengan `MAX_UPLOAD_MB`.

## Keamanan yang sudah ada

Password di-hash dengan scrypt, sesi cookie HttpOnly + SameSite=Strict, pembatasan percobaan login (8x per 15 menit), validasi ekstensi file upload, header keamanan + CSP, dan semua teks dari database di-escape di halaman.

## Struktur

```
server.js            backend (Express, YouTube API, upload, login)
views/               template halaman
public/css, js, img  aset statis
data/                db.json + uploads/ (dibuat otomatis, jangan di-commit)
```
