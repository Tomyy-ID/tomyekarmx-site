'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/* ---------- .env loader kecil (tanpa dependency) ---------- */
(function loadEnv() {
  const f = path.join(__dirname, '.env');
  if (!fs.existsSync(f)) return;
  for (const line of fs.readFileSync(f, 'utf8').split(/\r?\n/)) {
    if (line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
})();

const express = require('express');
const multer = require('multer');

/* ---------- Konfigurasi ---------- */
const cfg = {
  port: Number(process.env.PORT) || 3000,
  dataDir: path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data')),
  ytKey: process.env.YOUTUBE_API_KEY || '',
  unlockViews: Number(process.env.UNLOCK_VIEWS) || 1000,
  maxMb: Number(process.env.MAX_UPLOAD_MB) || 200,
  secureCookie: process.env.COOKIE_SECURE === '1',
  trustProxy: process.env.TRUST_PROXY === '1',
  site: {
    name: 'Tomy Eka RMX',
    tag: '«⟨BSB⟩»',
    youtube: 'https://youtube.com/@tomyekarmx_bsb',
    whatsapp: '6288980517964',
    email: 'ekaardianto4565@gmail.com',
    instagram: 'tomyeka_rmx',
    github: 'https://github.com/tomyy-id'
  }
};

const UPLOAD_DIR = path.join(cfg.dataDir, 'uploads');
const VIEWS_DIR = path.join(__dirname, 'views');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const KINDS = {
  flm: { label: 'FLM Project', icon: '🎛️' },
  vocal: { label: 'Vocal', icon: '🎤' },
  sample: { label: 'Sample', icon: '🥁' }
};
const ALLOWED_EXT = new Set(['.flm', '.zip', '.rar', '.7z', '.wav', '.mp3', '.flac', '.ogg', '.m4a', '.aac']);

/* ---------- Database JSON ---------- */
const dbFile = path.join(cfg.dataDir, 'db.json');
let db = { projects: [], admin: null };
if (fs.existsSync(dbFile)) db = Object.assign(db, JSON.parse(fs.readFileSync(dbFile, 'utf8')));
function saveDb() {
  const tmp = dbFile + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, dbFile);
}

/* ---------- Password admin ---------- */
function hashPass(pass, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(pass, salt, 64).toString('hex') };
}
function checkPass(pass, a) {
  const h = crypto.scryptSync(pass, a.salt, 64);
  const b = Buffer.from(a.hash, 'hex');
  return b.length === h.length && crypto.timingSafeEqual(h, b);
}
function safeEq(a, b) {
  const x = crypto.createHash('sha256').update(a).digest();
  const y = crypto.createHash('sha256').update(b).digest();
  return crypto.timingSafeEqual(x, y);
}
if (!db.admin) {
  const user = process.env.ADMIN_USER || 'admin';
  const generated = !process.env.ADMIN_PASS;
  const pass = process.env.ADMIN_PASS || crypto.randomBytes(9).toString('base64url');
  db.admin = Object.assign({ user }, hashPass(pass));
  saveDb();
  console.log('\n=== AKUN ADMIN DIBUAT ===');
  console.log('Username :', user);
  console.log('Password :', generated ? pass + '   (dibuat acak, segera ganti di dashboard)' : '(dari ADMIN_PASS)');
  console.log('=========================\n');
}

/* ---------- Sesi & rate limit ---------- */
const SESSION_MS = 12 * 60 * 60 * 1000;
const sessions = new Map();
const attempts = new Map();

function parseCookies(req) {
  const o = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) { try { o[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch { /* abaikan */ } }
  });
  return o;
}
function getSession(req) {
  const t = parseCookies(req).sid;
  const s = t && sessions.get(t);
  if (!s) return null;
  if (s.exp < Date.now()) { sessions.delete(t); return null; }
  s.exp = Date.now() + SESSION_MS;
  return Object.assign(s, { token: t });
}
const isAdmin = req => !!getSession(req);
function requireAdmin(req, res, next) {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Belum login' });
  req.session = s;
  next();
}
function cookieHeader(value, maxAge) {
  return `sid=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${cfg.secureCookie ? '; Secure' : ''}`;
}
function tooManyAttempts(ip) {
  const now = Date.now();
  const a = (attempts.get(ip) || []).filter(t => now - t < 15 * 60 * 1000);
  attempts.set(ip, a);
  return a.length >= 8;
}
setInterval(() => {
  const now = Date.now();
  for (const [k, s] of sessions) if (s.exp < now) sessions.delete(k);
}, 30 * 60 * 1000).unref();

/* ---------- Helper project ---------- */
function ytId(input) {
  const s = String(input || '').trim();
  if (/^[\w-]{11}$/.test(s)) return s;
  try {
    const u = new URL(s);
    const h = u.hostname.replace(/^(www|m)\./, '');
    if (h === 'youtu.be') {
      const id = u.pathname.slice(1).split('/')[0];
      return /^[\w-]{11}$/.test(id) ? id : null;
    }
    if (h.endsWith('youtube.com') || h.endsWith('youtube-nocookie.com')) {
      const v = u.searchParams.get('v');
      if (v && /^[\w-]{11}$/.test(v)) return v;
      const m = u.pathname.match(/^\/(?:shorts|embed|live|v)\/([\w-]{11})/);
      if (m) return m[1];
    }
  } catch { /* bukan URL */ }
  return null;
}
function slugify(t) {
  return String(t).toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'project';
}
function uniqueSlug(title) {
  const base = slugify(title);
  let s = base, i = 2;
  while (db.projects.some(p => p.slug === s)) s = `${base}-${i++}`;
  return s;
}
const isOpen = p => !!(p.unlocked || p.manualUnlock);

function downloadName(p, kind) {
  const f = p.files[kind];
  const ext = path.extname(f.original || '').toLowerCase() || '.zip';
  const safe = p.title.replace(/[\\/:*?"<>|\x00-\x1f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 100) || p.slug;
  return `${safe} - ${KINDS[kind].label}${ext}`;
}
function fileList(p) {
  return Object.keys(KINDS).filter(k => p.files && p.files[k]).map(k => ({
    kind: k, label: KINDS[k].label, icon: KINDS[k].icon,
    name: downloadName(p, k), size: p.files[k].size
  }));
}
function pubProject(p) {
  return {
    slug: p.slug, title: p.title, description: p.description, youtubeId: p.youtubeId,
    thumbnail: `https://i.ytimg.com/vi/${p.youtubeId}/hqdefault.jpg`,
    views: p.views, threshold: p.threshold, unlocked: isOpen(p),
    downloads: p.downloads || 0, createdAt: p.createdAt, files: fileList(p)
  };
}
function adminProject(p) {
  return Object.assign(pubProject(p), {
    id: p.id, published: p.published !== false, manualUnlock: !!p.manualUnlock,
    autoUnlocked: !!p.unlocked, checkedAt: p.checkedAt,
    youtubeUrl: `https://youtu.be/${p.youtubeId}`,
    originals: Object.fromEntries(Object.keys(KINDS).filter(k => p.files[k]).map(k => [k, p.files[k].original]))
  });
}

/* ---------- YouTube Data API ---------- */
const VIEW_TTL = 10 * 60 * 1000;
let inflight = null;

async function fetchViews(ids) {
  const out = new Map();
  if (!cfg.ytKey || !ids.length) return out;
  for (let i = 0; i < ids.length; i += 50) {
    const chunk = ids.slice(i, i + 50);
    const url = 'https://www.googleapis.com/youtube/v3/videos?part=statistics&id=' +
      chunk.join(',') + '&key=' + encodeURIComponent(cfg.ytKey);
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(8000) });
      if (!r.ok) { console.error('[YouTube API] HTTP', r.status); continue; }
      const j = await r.json();
      for (const it of j.items || []) out.set(it.id, Number(it.statistics && it.statistics.viewCount || 0));
    } catch (e) {
      console.error('[YouTube API]', e.message);
    }
  }
  return out;
}

async function refreshViews(projects, ttl = VIEW_TTL, force = false) {
  if (inflight) { await inflight; return; }
  const now = Date.now();
  const stale = projects.filter(p => p.youtubeId && !p.unlocked && (force || !p.checkedAt || now - p.checkedAt > ttl));
  if (!stale.length || !cfg.ytKey) return;
  inflight = (async () => {
    const map = await fetchViews([...new Set(stale.map(p => p.youtubeId))]);
    let changed = false;
    for (const p of stale) {
      if (map.has(p.youtubeId)) {
        p.views = map.get(p.youtubeId);
        p.checkedAt = now;
        if (p.views >= p.threshold) { p.unlocked = true; p.unlockedAt = now; }
        changed = true;
      } else {
        p.checkedAt = now - VIEW_TTL + 60 * 1000; // gagal: coba lagi sekitar 1 menit
      }
    }
    if (changed) saveDb();
  })();
  try { await inflight; } finally { inflight = null; }
}

/* ---------- Upload ---------- */
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: cfg.maxMb * 1024 * 1024, files: 3 },
  fileFilter: (req, file, cb) => {
    if (!Object.keys(KINDS).includes(file.fieldname)) return cb(new Error('Field file tidak dikenal'));
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_EXT.has(ext)) return cb(new Error(`Tipe file ${ext || '(tanpa ekstensi)'} tidak diizinkan. Gunakan: ${[...ALLOWED_EXT].join(', ')}`));
    cb(null, true);
  }
});
const uploadFields = upload.fields(Object.keys(KINDS).map(name => ({ name, maxCount: 1 })));

function removeStored(name) {
  if (!name) return;
  fs.unlink(path.join(UPLOAD_DIR, name), () => {});
}
function cleanupUploaded(req) {
  for (const arr of Object.values(req.files || {})) for (const f of arr) removeStored(f.filename);
}
function withUpload(req, res, next) {
  uploadFields(req, res, err => {
    if (err) {
      cleanupUploaded(req);
      const msg = err.code === 'LIMIT_FILE_SIZE' ? `File terlalu besar (maksimal ${cfg.maxMb} MB per file)` : err.message;
      return res.status(400).json({ error: msg });
    }
    next();
  });
}
function applyFiles(p, files, removeList) {
  p.files = p.files || {};
  for (const k of removeList) {
    if (KINDS[k] && p.files[k]) { removeStored(p.files[k].stored); delete p.files[k]; }
  }
  for (const k of Object.keys(KINDS)) {
    const f = files && files[k] && files[k][0];
    if (!f) continue;
    if (p.files[k]) removeStored(p.files[k].stored);
    p.files[k] = { stored: f.filename, original: f.originalname, size: f.size };
  }
}
function parseProjectBody(b) {
  const title = String(b.title || '').trim();
  if (!title) return { error: 'Judul wajib diisi' };
  if (title.length > 150) return { error: 'Judul maksimal 150 karakter' };
  const id = ytId(b.youtube);
  if (!id) return { error: 'Link/ID video YouTube tidak valid' };
  const threshold = Math.round(Number(b.threshold) || cfg.unlockViews);
  if (threshold < 1 || threshold > 1e9) return { error: 'Target view tidak valid' };
  const truthy = v => v === 'true' || v === 'on' || v === '1';
  return {
    data: {
      title, youtubeId: id,
      description: String(b.description || '').trim().slice(0, 2000),
      threshold,
      published: truthy(b.published),
      manualUnlock: truthy(b.manualUnlock)
    }
  };
}

/* ---------- Template halaman ---------- */
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const readView = f => fs.readFileSync(path.join(VIEWS_DIR, f), 'utf8');

function renderPage(content, { page = '', title, description, image = '' } = {}) {
  const s = cfg.site;
  const vars = {
    title: esc(title ? `${title} | ${s.name}` : `${s.name} ${s.tag} — DJ Trap Sholawat Slow Bass & FLM Project`),
    description: esc(description || 'Website resmi Tomy Eka RMX: DJ Trap Sholawat Slow Bass dan sharing project FL Studio Mobile (FLM) gratis setiap video mencapai 1K view.'),
    og_image: esc(image),
    page: esc(page),
    site_name: esc(s.name), site_tag: esc(s.tag),
    youtube: esc(s.youtube),
    wa_url: esc(`https://wa.me/${s.whatsapp}?text=${encodeURIComponent('Halo Tomy Eka RMX')}`),
    wa_display: esc('+' + s.whatsapp.replace(/^(\d{2})(\d{3})(\d{4})(\d+)$/, '$1 $2-$3-$4')),
    email: esc(s.email),
    instagram: esc('https://instagram.com/' + s.instagram), ig_handle: esc('@' + s.instagram),
    github: esc(s.github),
    year: String(new Date().getFullYear()),
    unlock_views: new Intl.NumberFormat('id-ID').format(cfg.unlockViews)
  };
  for (const n of ['home', 'project', 'about', 'contact']) vars['a_' + n] = page === n ? 'aria-current="page"' : '';
  let html = readView('layout.html')
    .replace('{{header}}', readView('header.html'))
    .replace('{{footer}}', readView('footer.html'))
    .replace('{{content}}', content);
  return html.replace(/\{\{(\w+)\}\}/g, (m, k) => (k in vars ? vars[k] : m));
}

/* ---------- App ---------- */
const app = express();
app.disable('x-powered-by');
if (cfg.trustProxy) app.set('trust proxy', 1);

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; img-src 'self' https://i.ytimg.com data:; frame-src https://www.youtube-nocookie.com; " +
    "style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  next();
});
app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h' }));

/* --- Halaman publik --- */
app.get('/', (req, res) => res.send(renderPage(readView('home.html'), { page: 'home' })));
app.get('/about', (req, res) => res.send(renderPage(readView('about.html'), {
  page: 'about', title: 'Tentang', description: 'Tentang Tomy Eka RMX — remixer DJ Trap Sholawat Slow Bass dan berbagi project FLM.'
})));
app.get('/contact', (req, res) => res.send(renderPage(readView('contact.html'), {
  page: 'contact', title: 'Kontak', description: 'Hubungi Tomy Eka RMX lewat WhatsApp, Email, atau Instagram.'
})));
app.get('/project', (req, res) => res.send(renderPage(readView('projects.html'), {
  page: 'project', title: 'Project', description: 'Daftar project FLM, vocal, dan sample gratis dari Tomy Eka RMX.'
})));
app.get('/project/:slug', (req, res) => {
  const p = db.projects.find(x => x.slug === req.params.slug && x.published !== false);
  if (!p) return res.status(404).send(renderPage(readView('notfound.html'), { title: 'Tidak ditemukan' }));
  res.send(renderPage(readView('project-detail.html'), {
    page: 'project', title: p.title,
    description: p.description || `Download FLM project, vocal, dan sample "${p.title}" gratis setelah video mencapai ${p.threshold} view.`,
    image: `https://i.ytimg.com/vi/${p.youtubeId}/hqdefault.jpg`
  }));
});
app.get('/admin/login', (req, res) => {
  if (isAdmin(req)) return res.redirect('/admin');
  res.sendFile(path.join(VIEWS_DIR, 'admin-login.html'));
});
app.get('/admin', (req, res) => {
  if (!isAdmin(req)) return res.redirect('/admin/login');
  res.sendFile(path.join(VIEWS_DIR, 'admin-dashboard.html'));
});

/* --- API publik --- */
app.get('/api/projects', async (req, res) => {
  const visible = db.projects.filter(p => p.published !== false);
  refreshViews(visible).catch(() => {}); // stale-while-revalidate
  const limit = Math.min(Number(req.query.limit) || 100, 100);
  res.json({
    total: visible.length,
    unlocked: visible.filter(isOpen).length,
    threshold: cfg.unlockViews,
    items: visible.slice(0, limit).map(pubProject)
  });
});
app.get('/api/projects/:slug', async (req, res) => {
  const p = db.projects.find(x => x.slug === req.params.slug && x.published !== false);
  if (!p) return res.status(404).json({ error: 'Project tidak ditemukan' });
  await refreshViews([p]);
  res.json(pubProject(p));
});

/* --- Download (dijaga di server, tidak bisa dilewati lewat URL) --- */
app.get('/download/:slug/:kind', async (req, res) => {
  const admin = isAdmin(req);
  const p = db.projects.find(x => x.slug === req.params.slug && (x.published !== false || admin));
  const kind = req.params.kind;
  if (!p || !KINDS[kind] || !p.files || !p.files[kind]) return res.status(404).type('text').send('File tidak ditemukan');
  if (!isOpen(p) && !admin) await refreshViews([p], 2 * 60 * 1000);
  if (!isOpen(p) && !admin) {
    return res.status(403).type('text').send(`File masih terkunci. Video harus mencapai ${p.threshold} view terlebih dahulu.`);
  }
  const fp = path.join(UPLOAD_DIR, path.basename(p.files[kind].stored));
  if (!fs.existsSync(fp)) return res.status(404).type('text').send('File tidak ditemukan di server');
  if (!admin) { p.downloads = (p.downloads || 0) + 1; saveDb(); }
  res.download(fp, downloadName(p, kind));
});

/* --- API admin --- */
app.post('/api/admin/login', (req, res) => {
  const ip = req.ip;
  if (tooManyAttempts(ip)) return res.status(429).json({ error: 'Terlalu banyak percobaan. Coba lagi dalam 15 menit.' });
  const { username = '', password = '' } = req.body || {};
  const okUser = safeEq(String(username), db.admin.user);
  const okPass = checkPass(String(password), db.admin);
  if (!(okUser && okPass)) {
    attempts.get(ip).push(Date.now());
    return res.status(401).json({ error: 'Username atau password salah' });
  }
  attempts.delete(ip);
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { exp: Date.now() + SESSION_MS });
  res.setHeader('Set-Cookie', cookieHeader(token, SESSION_MS / 1000));
  res.json({ ok: true });
});
app.post('/api/admin/logout', requireAdmin, (req, res) => {
  sessions.delete(req.session.token);
  res.setHeader('Set-Cookie', cookieHeader('', 0));
  res.json({ ok: true });
});
app.get('/api/admin/me', requireAdmin, (req, res) => {
  res.json({ user: db.admin.user, youtubeApi: !!cfg.ytKey, defaultThreshold: cfg.unlockViews, maxMb: cfg.maxMb });
});
app.post('/api/admin/password', requireAdmin, (req, res) => {
  const { current = '', next = '' } = req.body || {};
  if (!checkPass(String(current), db.admin)) return res.status(400).json({ error: 'Password saat ini salah' });
  if (String(next).length < 8) return res.status(400).json({ error: 'Password baru minimal 8 karakter' });
  db.admin = Object.assign({ user: db.admin.user }, hashPass(String(next)));
  saveDb();
  for (const k of sessions.keys()) if (k !== req.session.token) sessions.delete(k);
  res.json({ ok: true });
});

app.get('/api/admin/projects', requireAdmin, async (req, res) => {
  await refreshViews(db.projects);
  res.json({ items: db.projects.map(adminProject) });
});
app.post('/api/admin/projects', requireAdmin, withUpload, async (req, res) => {
  const v = parseProjectBody(req.body);
  if (v.error) { cleanupUploaded(req); return res.status(400).json({ error: v.error }); }
  const p = Object.assign({
    id: crypto.randomUUID(), slug: uniqueSlug(v.data.title), files: {},
    views: null, checkedAt: 0, unlocked: false, downloads: 0, createdAt: Date.now()
  }, v.data);
  applyFiles(p, req.files, []);
  db.projects.unshift(p);
  saveDb();
  await refreshViews([p], 0, true);
  res.json(adminProject(p));
});
app.put('/api/admin/projects/:id', requireAdmin, withUpload, async (req, res) => {
  const p = db.projects.find(x => x.id === req.params.id);
  if (!p) { cleanupUploaded(req); return res.status(404).json({ error: 'Project tidak ditemukan' }); }
  const v = parseProjectBody(req.body);
  if (v.error) { cleanupUploaded(req); return res.status(400).json({ error: v.error }); }
  const videoChanged = v.data.youtubeId !== p.youtubeId;
  Object.assign(p, v.data);
  if (videoChanged) { p.views = null; p.checkedAt = 0; p.unlocked = false; }
  else if (!p.unlocked && p.views != null && p.views >= p.threshold) { p.unlocked = true; p.unlockedAt = Date.now(); }
  applyFiles(p, req.files, String(req.body.removeFiles || '').split(',').map(s => s.trim()).filter(Boolean));
  saveDb();
  if (videoChanged) await refreshViews([p], 0, true);
  res.json(adminProject(p));
});
app.post('/api/admin/projects/:id/refresh', requireAdmin, async (req, res) => {
  const p = db.projects.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Project tidak ditemukan' });
  if (!cfg.ytKey) return res.status(400).json({ error: 'YOUTUBE_API_KEY belum diisi di server' });
  await refreshViews([p], 0, true);
  res.json(adminProject(p));
});
app.delete('/api/admin/projects/:id', requireAdmin, (req, res) => {
  const i = db.projects.findIndex(x => x.id === req.params.id);
  if (i < 0) return res.status(404).json({ error: 'Project tidak ditemukan' });
  const [p] = db.projects.splice(i, 1);
  for (const f of Object.values(p.files || {})) removeStored(f.stored);
  saveDb();
  res.json({ ok: true });
});

/* --- 404 & error --- */
app.use('/api', (req, res) => res.status(404).json({ error: 'Endpoint tidak ditemukan' }));
app.use((req, res) => res.status(404).send(renderPage(readView('notfound.html'), { title: 'Tidak ditemukan' })));
app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  console.error(err);
  if (req.path.startsWith('/api')) return res.status(500).json({ error: 'Terjadi kesalahan server' });
  res.status(500).type('text').send('Terjadi kesalahan server');
});

app.listen(cfg.port, () => {
  console.log(`Server berjalan di http://localhost:${cfg.port}`);
  if (!cfg.ytKey) console.warn('PERINGATAN: YOUTUBE_API_KEY belum diisi — view tidak akan dicek, file tidak terbuka otomatis.');
});
