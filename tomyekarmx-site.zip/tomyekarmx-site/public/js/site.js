(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const nf = new Intl.NumberFormat('id-ID');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtSize = b => (b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');
  const pct = p => (p.views == null ? 0 : Math.min(100, Math.floor((p.views / p.threshold) * 100)));

  /* menu mobile */
  const toggle = $('.nav-toggle');
  const menu = $('#menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const open = menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
  }

  function card(p) {
    const done = p.unlocked;
    const viewsText = p.views == null ? 'View belum tersedia' : nf.format(p.views) + ' view';
    return `<article class="card project-card">
      <a class="thumb" href="/project/${encodeURIComponent(p.slug)}" aria-label="${esc(p.title)}">
        <img loading="lazy" src="${esc(p.thumbnail)}" alt="">
        <span class="badge ${done ? 'open' : 'locked'}">${done ? '🔓 Terbuka' : '🔒 Terkunci'}</span>
      </a>
      <div class="card-body">
        <h3><a href="/project/${encodeURIComponent(p.slug)}">${esc(p.title)}</a></h3>
        <div class="meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${done ? 100 : pct(p)}">
          <div class="meter-bar ${done ? 'done' : ''}" style="width:${done ? 100 : pct(p)}%"></div>
        </div>
        <div class="meter-text"><span>${viewsText}</span><span>Target ${nf.format(p.threshold)}</span></div>
      </div>
    </article>`;
  }

  async function getJSON(url) {
    const r = await fetch(url, { headers: { Accept: 'application/json' } });
    if (!r.ok) throw new Error((await r.json().catch(() => ({}))).error || 'Gagal memuat');
    return r.json();
  }

  /* Beranda */
  async function initHome() {
    const box = $('#latest-projects');
    try {
      const d = await getJSON('/api/projects?limit=3');
      $('#st-total').textContent = nf.format(d.total);
      $('#st-open').textContent = nf.format(d.unlocked);
      box.innerHTML = d.items.length ? d.items.map(card).join('') : '<p class="muted">Belum ada project. Segera hadir!</p>';
    } catch (e) {
      box.innerHTML = '<p class="muted">Project gagal dimuat. Coba muat ulang halaman.</p>';
    }
  }

  /* Daftar project */
  async function initList() {
    const box = $('#all-projects');
    let items = [];
    let filter = 'all';
    let q = '';
    const draw = () => {
      const list = items.filter(p =>
        (filter === 'all' || (filter === 'open') === p.unlocked) &&
        p.title.toLowerCase().includes(q));
      box.innerHTML = list.length ? list.map(card).join('') : '<p class="muted">Tidak ada project yang cocok.</p>';
    };
    try {
      items = (await getJSON('/api/projects')).items;
      draw();
    } catch (e) {
      box.innerHTML = '<p class="muted">Project gagal dimuat. Coba muat ulang halaman.</p>';
      return;
    }
    $('#search').addEventListener('input', e => { q = e.target.value.trim().toLowerCase(); draw(); });
    document.querySelectorAll('.chip').forEach(c => c.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
      c.classList.add('active');
      filter = c.dataset.filter;
      draw();
    }));
  }

  /* Detail project */
  async function initDetail() {
    const box = $('#detail');
    const slug = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || '');
    let p;
    try { p = await getJSON('/api/projects/' + encodeURIComponent(slug)); }
    catch (e) { box.innerHTML = '<p class="muted">Project tidak ditemukan.</p>'; return; }

    const remaining = p.views == null ? null : Math.max(0, p.threshold - p.views);
    const files = p.files.length
      ? p.files.map(f => {
          const action = p.unlocked
            ? `<a class="btn btn-primary btn-sm" href="/download/${encodeURIComponent(p.slug)}/${f.kind}">⬇ Download</a>`
            : `<span class="btn btn-sm disabled" aria-disabled="true">🔒 Terkunci</span>`;
          return `<li class="file"><span class="fi">${f.icon}</span>
            <span class="fn"><b>${esc(f.label)}</b><small title="${esc(f.name)}">${esc(f.name)} · ${fmtSize(f.size)}</small></span>${action}</li>`;
        }).join('')
      : '<li class="muted">File belum diunggah.</li>';

    const status = p.unlocked
      ? '<div class="note ok">🎉 Target view tercapai — semua file terbuka. Selamat belajar &amp; berkarya!</div>'
      : `<div class="note lock">🔒 File terbuka otomatis saat video mencapai <b>${nf.format(p.threshold)}</b> view.${
          remaining != null ? ` Tinggal <b>${nf.format(remaining)}</b> view lagi — bantu bagikan videonya!` : ''}</div>`;

    document.title = p.title + ' | Tomy Eka RMX';
    box.innerHTML = `
      <div class="crumbs"><a href="/project">Project</a> / ${esc(p.title)}</div>
      <h1>${esc(p.title)}</h1>
      <div class="detail-grid">
        <div>
          <div class="player"><iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(p.youtubeId)}" title="${esc(p.title)}" loading="lazy" allow="accelerometer; encrypted-media; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
          ${p.description ? `<div class="panel" style="margin-top:1rem"><p class="desc" style="margin:0">${esc(p.description)}</p></div>` : ''}
        </div>
        <aside class="panel">
          <h3>Download Project</h3>
          <div class="meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p.unlocked ? 100 : pct(p)}"><div class="meter-bar ${p.unlocked ? 'done' : ''}" style="width:${p.unlocked ? 100 : pct(p)}%"></div></div>
          <div class="meter-text"><span>${p.views == null ? 'View belum tersedia' : nf.format(p.views) + ' view'}</span><span>Target ${nf.format(p.threshold)}</span></div>
          ${status}
          <ul class="files">${files}</ul>
          <p class="muted" style="margin:1rem 0 0;font-size:.85rem">${nf.format(p.downloads)}× diunduh</p>
        </aside>
      </div>`;
  }

  const page = document.body.dataset.page;
  if (page === 'home') initHome();
  else if (page === 'project' && $('#all-projects')) initList();
  else if (page === 'project' && $('#detail')) initDetail();
})();
