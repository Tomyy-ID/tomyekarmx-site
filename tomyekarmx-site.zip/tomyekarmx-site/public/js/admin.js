(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const nf = new Intl.NumberFormat('id-ID');
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtSize = b => (b >= 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB');

  let me = null;
  let items = [];
  let editing = null;
  let removeFiles = new Set();

  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2800);
  }

  async function api(url, opts = {}) {
    const r = await fetch(url, Object.assign({ headers: { 'Content-Type': 'application/json' } }, opts));
    if (r.status === 401) { location.href = '/admin/login'; throw new Error('Sesi berakhir'); }
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Permintaan gagal');
    return j;
  }

  function sendForm(method, url, fd, onProgress) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open(method, url);
      x.upload.onprogress = e => { if (e.lengthComputable) onProgress(e.loaded / e.total); };
      x.onload = () => {
        let j = {};
        try { j = JSON.parse(x.responseText); } catch { /* kosong */ }
        if (x.status === 401) { location.href = '/admin/login'; return; }
        if (x.status >= 200 && x.status < 300) resolve(j);
        else reject(new Error(j.error || 'Gagal menyimpan (' + x.status + ')'));
      };
      x.onerror = () => reject(new Error('Koneksi terputus'));
      x.send(fd);
    });
  }

  /* ---------- daftar ---------- */
  function render() {
    const open = items.filter(p => p.unlocked).length;
    $('#summary').textContent = `${items.length} project · ${open} terbuka`;
    $('#list').innerHTML = items.length ? items.map(p => {
      const tags = [
        p.published ? '<span class="tag green">Publik</span>' : '<span class="tag">Draft</span>',
        p.unlocked ? '<span class="tag green">🔓 Terbuka</span>' : '<span class="tag violet">🔒 Terkunci</span>',
        p.manualUnlock ? '<span class="tag red">Buka manual</span>' : '',
        ...p.files.map(f => `<span class="tag">${f.icon} ${esc(f.label)}</span>`)
      ].join('');
      return `<article class="card admin-item" data-id="${esc(p.id)}">
        <img src="${esc(p.thumbnail)}" alt="" loading="lazy">
        <div>
          <h3>${esc(p.title)}</h3>
          <div class="meta"><span>${p.views == null ? 'View: –' : nf.format(p.views) + ' / ' + nf.format(p.threshold) + ' view'}</span><span>· ${nf.format(p.downloads)}× diunduh</span></div>
          <div class="meta" style="margin-top:.4rem">${tags}</div>
        </div>
        <div class="admin-actions">
          <a class="btn btn-sm" href="/project/${encodeURIComponent(p.slug)}" target="_blank" rel="noopener">Lihat</a>
          <button class="btn btn-sm" data-act="refresh" type="button">Cek view</button>
          <button class="btn btn-sm" data-act="edit" type="button">Edit</button>
          <button class="btn btn-sm btn-danger" data-act="delete" type="button">Hapus</button>
        </div>
      </article>`;
    }).join('') : '<p class="muted">Belum ada project. Klik “+ Project baru” untuk mulai.</p>';
  }

  async function load() {
    items = (await api('/api/admin/projects')).items;
    render();
  }

  $('#list').addEventListener('click', async e => {
    const btn = e.target.closest('button[data-act]');
    if (!btn) return;
    const id = btn.closest('.admin-item').dataset.id;
    const p = items.find(x => x.id === id);
    const act = btn.dataset.act;
    try {
      if (act === 'edit') openForm(p);
      if (act === 'refresh') {
        btn.disabled = true;
        const u = await api(`/api/admin/projects/${id}/refresh`, { method: 'POST' });
        items = items.map(x => (x.id === id ? u : x));
        render();
        toast('View diperbarui: ' + nf.format(u.views == null ? 0 : u.views));
      }
      if (act === 'delete') {
        if (!confirm(`Hapus project "${p.title}" beserta semua file-nya? Tindakan ini tidak bisa dibatalkan.`)) return;
        await api(`/api/admin/projects/${id}`, { method: 'DELETE' });
        items = items.filter(x => x.id !== id);
        render();
        toast('Project dihapus');
      }
    } catch (ex) {
      toast(ex.message);
      btn.disabled = false;
    }
  });

  /* ---------- form project ---------- */
  const dlg = $('#project-dialog');
  const form = $('#project-form');

  function drawCurrent() {
    for (const k of ['flm', 'vocal', 'sample']) {
      const box = $(`[data-cur="${k}"]`);
      const f = editing && editing.files.find(x => x.kind === k);
      if (f && !removeFiles.has(k)) {
        box.innerHTML = `<span>Terunggah: ${esc(editing.originals[k])} (${fmtSize(f.size)})</span><button type="button" class="btn btn-sm btn-danger" data-remove="${k}">Hapus file</button>`;
      } else if (f && removeFiles.has(k)) {
        box.innerHTML = '<span>File akan dihapus saat disimpan</span>';
      } else {
        box.textContent = '';
      }
    }
  }

  function openForm(p) {
    editing = p || null;
    removeFiles = new Set();
    form.reset();
    $('#form-err').hidden = true;
    $('#progress').classList.remove('show');
    $('#dlg-title').textContent = p ? 'Edit project' : 'Project baru';
    $('#f-title').value = p ? p.title : '';
    $('#f-youtube').value = p ? p.youtubeUrl : '';
    $('#f-desc').value = p ? p.description : '';
    $('#f-threshold').value = p ? p.threshold : me.defaultThreshold;
    $('#f-published').checked = p ? p.published : true;
    $('#f-manual').checked = p ? p.manualUnlock : false;
    $('#limit-note').textContent = `Format: .flm, .zip, .rar, .7z, audio (.wav .mp3 .flac .ogg .m4a .aac). Maks ${me.maxMb} MB per file. Kosongkan jika tidak ingin mengubah file.`;
    drawCurrent();
    dlg.showModal();
  }

  $('#btn-new').addEventListener('click', () => openForm(null));
  $('#dlg-cancel').addEventListener('click', () => dlg.close());
  form.addEventListener('click', e => {
    const b = e.target.closest('[data-remove]');
    if (b) { removeFiles.add(b.dataset.remove); drawCurrent(); }
  });

  form.addEventListener('submit', async e => {
    e.preventDefault();
    const err = $('#form-err');
    err.hidden = true;
    const fd = new FormData();
    fd.append('title', $('#f-title').value);
    fd.append('youtube', $('#f-youtube').value);
    fd.append('description', $('#f-desc').value);
    fd.append('threshold', $('#f-threshold').value);
    fd.append('published', $('#f-published').checked ? 'true' : 'false');
    fd.append('manualUnlock', $('#f-manual').checked ? 'true' : 'false');
    fd.append('removeFiles', [...removeFiles].join(','));
    for (const k of ['flm', 'vocal', 'sample']) {
      const f = $('#f-' + k).files[0];
      if (f) {
        if (f.size > me.maxMb * 1048576) { err.textContent = `${f.name} terlalu besar (maks ${me.maxMb} MB)`; err.hidden = false; return; }
        fd.append(k, f);
      }
    }
    const save = $('#dlg-save');
    const bar = $('#progress');
    save.disabled = true;
    bar.classList.add('show');
    try {
      const url = editing ? `/api/admin/projects/${editing.id}` : '/api/admin/projects';
      const saved = await sendForm(editing ? 'PUT' : 'POST', url, fd, r => { bar.firstElementChild.style.width = Math.round(r * 100) + '%'; });
      items = editing ? items.map(x => (x.id === saved.id ? saved : x)) : [saved, ...items];
      render();
      dlg.close();
      toast('Project disimpan');
    } catch (ex) {
      err.textContent = ex.message;
      err.hidden = false;
    } finally {
      save.disabled = false;
      bar.classList.remove('show');
      bar.firstElementChild.style.width = '0';
    }
  });

  /* ---------- password & logout ---------- */
  const pdlg = $('#pass-dialog');
  $('#btn-pass').addEventListener('click', () => { $('#pass-form').reset(); $('#pass-err').hidden = true; pdlg.showModal(); });
  $('#pass-cancel').addEventListener('click', () => pdlg.close());
  $('#pass-form').addEventListener('submit', async e => {
    e.preventDefault();
    try {
      await api('/api/admin/password', { method: 'POST', body: JSON.stringify({ current: $('#p-cur').value, next: $('#p-new').value }) });
      pdlg.close();
      toast('Password diganti');
    } catch (ex) {
      $('#pass-err').textContent = ex.message;
      $('#pass-err').hidden = false;
    }
  });
  $('#btn-logout').addEventListener('click', async () => {
    try { await api('/api/admin/logout', { method: 'POST' }); } finally { location.href = '/admin/login'; }
  });

  /* ---------- mulai ---------- */
  (async function init() {
    try {
      me = await api('/api/admin/me');
      $('#api-warning').hidden = me.youtubeApi;
      await load();
    } catch (ex) {
      $('#summary').textContent = ex.message;
    }
  })();
})();
